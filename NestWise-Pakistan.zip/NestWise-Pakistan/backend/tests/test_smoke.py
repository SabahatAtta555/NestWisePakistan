import unittest

from app import app


class NestWiseApiSmokeTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        app.config.update(TESTING=True)
        cls.client = app.test_client()

    def test_health_endpoint(self):
        response = self.client.get('/api/health')
        self.assertEqual(response.status_code, 200)
        data = response.get_json()
        self.assertEqual(data['status'], 'ok')
        self.assertEqual(data['database'], 'sqlite')

    def test_sale_listings_are_available(self):
        response = self.client.get('/api/listings?listing_for=sale')
        self.assertEqual(response.status_code, 200)
        listings = response.get_json()
        self.assertGreater(len(listings), 0)
        self.assertTrue(all(item['listing_for'] == 'sale' for item in listings))

    def test_buy_agent_returns_ranked_recommendations(self):
        response = self.client.post(
            '/api/agent/recommend',
            json={
                'intent': 'buy',
                'city': 'Islamabad',
                'property_type': 'house',
                'budget': 90000000,
                'budget_unit': 'total',
                'purpose': 'family',
            },
        )
        self.assertEqual(response.status_code, 200)
        data = response.get_json()
        self.assertEqual(data['interpreted']['intent'], 'buy')
        self.assertGreater(len(data['recommendations']), 0)
        self.assertIn('confidence', data['recommendations'][0])


if __name__ == '__main__':
    unittest.main()
