import json
import math
import os
import sqlite3
import time
import urllib.parse
import urllib.request
from datetime import datetime, timedelta, timezone
from functools import wraps
from pathlib import Path

import jwt
from flask import Flask, jsonify, request
from flask_cors import CORS
from werkzeug.security import check_password_hash, generate_password_hash

BASE_DIR = Path(__file__).resolve().parent
DB_PATH = BASE_DIR / "nestwise.db"
JWT_SECRET = os.getenv("JWT_SECRET", "change-me-in-production")
JWT_EXP_HOURS = 24
APP_CONTACT = os.getenv("APP_CONTACT_EMAIL", "portfolio@example.com")
NOMINATIM_ENABLED = os.getenv("NOMINATIM_ENABLED", "true").lower() == "true"
OVERPASS_ENABLED = os.getenv("OVERPASS_ENABLED", "true").lower() == "true"

app = Flask(__name__)
CORS(app, resources={r"/api/*": {"origins": "*"}})

_last_nominatim_call = 0.0


def get_db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    return conn


def ensure_listing_columns(conn):
    """Add v2 marketplace fields when a user runs this over the older database."""
    existing = {row["name"] for row in conn.execute("PRAGMA table_info(listings)").fetchall()}
    columns = {
        "listing_for": "TEXT NOT NULL DEFAULT 'rent'",
        "sale_price": "INTEGER",
        "area_size": "REAL",
        "area_unit": "TEXT",
        "property_subtype": "TEXT",
        "seller_type": "TEXT NOT NULL DEFAULT 'owner'",
        "source_name": "TEXT",
        "source_url": "TEXT",
        "listed_at": "TEXT",
    }
    for name, definition in columns.items():
        if name not in existing:
            conn.execute(f"ALTER TABLE listings ADD COLUMN {name} {definition}")


def init_db():
    conn = get_db()
    conn.executescript(
        """
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            email TEXT NOT NULL UNIQUE,
            password_hash TEXT NOT NULL,
            created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
        );

        CREATE TABLE IF NOT EXISTS listings (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            title TEXT NOT NULL,
            city TEXT NOT NULL,
            area TEXT NOT NULL,
            property_type TEXT NOT NULL CHECK(property_type IN ('house','hostel','hotel')),
            price INTEGER NOT NULL,
            price_unit TEXT NOT NULL CHECK(price_unit IN ('month','night')),
            bedrooms INTEGER NOT NULL DEFAULT 1,
            bathrooms INTEGER NOT NULL DEFAULT 1,
            furnished INTEGER NOT NULL DEFAULT 1,
            gender_policy TEXT NOT NULL DEFAULT 'any',
            family_friendly INTEGER NOT NULL DEFAULT 1,
            student_friendly INTEGER NOT NULL DEFAULT 1,
            security INTEGER NOT NULL DEFAULT 1,
            wifi INTEGER NOT NULL DEFAULT 1,
            parking INTEGER NOT NULL DEFAULT 0,
            ac INTEGER NOT NULL DEFAULT 0,
            kitchen INTEGER NOT NULL DEFAULT 0,
            laundry INTEGER NOT NULL DEFAULT 0,
            transport_score INTEGER NOT NULL DEFAULT 3,
            safety_score REAL NOT NULL DEFAULT 4.0,
            rating REAL NOT NULL DEFAULT 4.0,
            reviews INTEGER NOT NULL DEFAULT 0,
            lat REAL NOT NULL,
            lng REAL NOT NULL,
            description TEXT NOT NULL,
            image_key TEXT NOT NULL,
            verified_demo INTEGER NOT NULL DEFAULT 1,
            listing_for TEXT NOT NULL DEFAULT 'rent',
            sale_price INTEGER,
            area_size REAL,
            area_unit TEXT,
            property_subtype TEXT,
            seller_type TEXT NOT NULL DEFAULT 'owner',
            source_name TEXT,
            source_url TEXT,
            listed_at TEXT
        );

        CREATE TABLE IF NOT EXISTS favorites (
            user_id INTEGER NOT NULL,
            listing_id INTEGER NOT NULL,
            created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (user_id, listing_id),
            FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE,
            FOREIGN KEY(listing_id) REFERENCES listings(id) ON DELETE CASCADE
        );

        CREATE TABLE IF NOT EXISTS inquiries (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER,
            listing_id INTEGER NOT NULL,
            name TEXT NOT NULL,
            phone TEXT NOT NULL,
            move_in TEXT,
            guests INTEGER NOT NULL DEFAULT 1,
            message TEXT,
            status TEXT NOT NULL DEFAULT 'pending',
            created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE SET NULL,
            FOREIGN KEY(listing_id) REFERENCES listings(id) ON DELETE CASCADE
        );

        CREATE TABLE IF NOT EXISTS geo_cache (
            query TEXT PRIMARY KEY,
            payload TEXT NOT NULL,
            updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
        );

        CREATE TABLE IF NOT EXISTS market_websites (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL UNIQUE,
            url TEXT NOT NULL,
            category TEXT NOT NULL,
            description TEXT NOT NULL
        );
        """
    )
    ensure_listing_columns(conn)

    count = conn.execute("SELECT COUNT(*) AS c FROM listings").fetchone()["c"]
    if count == 0:
        seed_listings(conn)

    sale_count = conn.execute("SELECT COUNT(*) AS c FROM listings WHERE listing_for='sale'").fetchone()["c"]
    if sale_count == 0:
        seed_sale_listings(conn)

    website_count = conn.execute("SELECT COUNT(*) AS c FROM market_websites").fetchone()["c"]
    if website_count == 0:
        seed_market_websites(conn)

    demo = conn.execute("SELECT id FROM users WHERE email = ?", ("demo@nestwise.pk",)).fetchone()
    if not demo:
        conn.execute(
            "INSERT INTO users(name,email,password_hash) VALUES(?,?,?)",
            ("Demo User", "demo@nestwise.pk", generate_password_hash("Demo123!")),
        )
    conn.commit()
    conn.close()


def seed_listings(conn):
    rows = [
        ("Margalla View Residence", "Islamabad", "F-8", "house", 95000, "month", 3, 3, 1, "any", 1, 0, 1, 1, 1, 1, 1, 1, 5, 4.7, 4.8, 38, 33.7123, 73.0395, "Furnished family home near F-8 Markaz with secure parking, backup power and fast internet.", "islamabad-house"),
        ("Blue Area Executive Rooms", "Islamabad", "Blue Area", "hotel", 12500, "night", 1, 1, 1, "any", 1, 0, 1, 1, 1, 1, 0, 1, 5, 4.5, 4.6, 91, 33.7178, 73.0718, "Central business-district stay designed for short work trips, with Wi-Fi and quick access to offices.", "islamabad-hotel"),
        ("Campus Nest Girls Hostel", "Islamabad", "H-13", "hostel", 22000, "month", 1, 1, 1, "women", 0, 1, 1, 1, 0, 0, 1, 1, 4, 4.2, 4.4, 56, 33.6459, 72.9992, "Women-only student hostel with furnished rooms, study space, mess option and university shuttle access.", "islamabad-hostel"),
        ("Saddar Workstay Hostel", "Rawalpindi", "Saddar", "hostel", 18500, "month", 1, 1, 1, "men", 0, 1, 1, 1, 0, 0, 0, 1, 5, 4.0, 4.2, 44, 33.5984, 73.0479, "Budget-friendly men's hostel close to public transport, markets and commercial offices.", "rawalpindi-hostel"),
        ("Bahria Family Apartment", "Rawalpindi", "Bahria Town Phase 7", "house", 72000, "month", 2, 2, 1, "any", 1, 0, 1, 1, 1, 1, 1, 1, 3, 4.8, 4.7, 29, 33.5221, 73.1147, "Modern two-bedroom apartment for families seeking gated security, parking and nearby retail.", "rawalpindi-house"),
        ("Gulberg City Suites", "Lahore", "Gulberg III", "hotel", 14500, "night", 1, 1, 1, "any", 1, 0, 1, 1, 1, 1, 0, 1, 5, 4.4, 4.6, 120, 31.5101, 74.3441, "Business hotel-style rooms near MM Alam Road with breakfast option, Wi-Fi and on-site parking.", "lahore-hotel"),
        ("Johar Town Student Lodge", "Lahore", "Johar Town", "hostel", 20000, "month", 1, 1, 1, "any", 0, 1, 1, 1, 0, 1, 1, 1, 4, 4.1, 4.3, 67, 31.4697, 74.2728, "Student-focused hostel near universities and coaching centers with laundry and shared kitchen.", "lahore-hostel"),
        ("DHA Lahore Family Home", "Lahore", "DHA Phase 5", "house", 140000, "month", 4, 4, 0, "any", 1, 0, 1, 1, 1, 1, 1, 1, 3, 4.9, 4.7, 18, 31.4690, 74.4115, "Spacious house in a gated neighborhood for larger families, with parking and independent kitchen.", "lahore-house"),
        ("Clifton Seaview Suites", "Karachi", "Clifton", "hotel", 16000, "night", 1, 1, 1, "any", 1, 0, 1, 1, 1, 1, 0, 1, 4, 4.3, 4.5, 143, 24.8138, 67.0303, "Short-stay suites for families and professionals with quick access to Clifton and Seaview.", "karachi-hotel"),
        ("Gulshan Shared Living", "Karachi", "Gulshan-e-Iqbal", "hostel", 24000, "month", 1, 1, 1, "any", 0, 1, 1, 1, 0, 1, 1, 1, 5, 4.0, 4.2, 82, 24.9207, 67.0897, "Co-living style hostel for students and early-career professionals with transport links and Wi-Fi.", "karachi-hostel"),
        ("PECHS Family Portion", "Karachi", "PECHS", "house", 110000, "month", 3, 3, 0, "any", 1, 0, 1, 1, 1, 1, 1, 1, 4, 4.3, 4.5, 31, 24.8726, 67.0645, "Independent family portion in a central Karachi neighborhood with parking and nearby schools.", "karachi-house"),
        ("University Town Hostel", "Peshawar", "University Town", "hostel", 17000, "month", 1, 1, 1, "men", 0, 1, 1, 1, 0, 0, 1, 1, 4, 4.1, 4.3, 36, 34.0002, 71.4887, "Affordable men's accommodation for students with shared kitchen and access to university routes.", "peshawar-hostel"),
        ("Hayatabad Guest Suites", "Peshawar", "Hayatabad", "hotel", 9000, "night", 1, 1, 1, "any", 1, 0, 1, 1, 1, 1, 0, 1, 4, 4.5, 4.4, 48, 33.9748, 71.4367, "Clean guest suites suited to medical visits and family stays, close to key Hayatabad services.", "peshawar-hotel"),
        ("Canal Road Family House", "Faisalabad", "Canal Road", "house", 65000, "month", 3, 2, 0, "any", 1, 0, 1, 1, 1, 1, 1, 0, 4, 4.2, 4.4, 25, 31.4306, 73.1239, "Three-bedroom family house near commercial areas with parking and convenient road access.", "faisalabad-house"),
        ("Clock Tower Budget Stay", "Faisalabad", "Civil Lines", "hotel", 7200, "night", 1, 1, 1, "any", 1, 0, 1, 1, 0, 1, 0, 1, 5, 3.9, 4.1, 39, 31.4204, 73.0791, "Practical short-stay rooms for travelers wanting central access and public transport.", "faisalabad-hotel"),
        ("Bosan Road Student House", "Multan", "Bosan Road", "hostel", 16500, "month", 1, 1, 1, "any", 0, 1, 1, 1, 0, 0, 1, 1, 4, 4.0, 4.2, 42, 30.2379, 71.4697, "Student accommodation near education hubs with Wi-Fi, laundry and shared common areas.", "multan-hostel"),
        ("Cantt Family Apartment", "Multan", "Multan Cantt", "house", 58000, "month", 2, 2, 1, "any", 1, 0, 1, 1, 1, 1, 1, 1, 4, 4.6, 4.5, 22, 30.1928, 71.4697, "Furnished apartment for families and professionals near Cantt markets and transport.", "multan-house"),
        ("Mall Road Hill Hotel", "Murree", "Mall Road", "hotel", 13500, "night", 1, 1, 1, "any", 1, 0, 1, 1, 0, 1, 0, 1, 4, 4.1, 4.3, 105, 33.9070, 73.3943, "Central hill-station stay for couples and families within walking distance of Mall Road attractions.", "murree-hotel"),
        ("Bhurbhan Family Cottage", "Murree", "Bhurban", "house", 155000, "month", 3, 3, 1, "any", 1, 0, 1, 1, 1, 1, 1, 1, 2, 4.8, 4.6, 27, 33.9546, 73.4515, "Furnished cottage for longer family stays in a quieter hill area, with kitchen and parking.", "murree-house"),
        ("Jinnah Town Family House", "Quetta", "Jinnah Town", "house", 62000, "month", 3, 2, 0, "any", 1, 0, 1, 1, 1, 0, 1, 0, 3, 4.1, 4.3, 21, 30.1837, 66.9987, "Practical family house in Jinnah Town with parking, security and access to daily shopping.", "quetta-house"),
        ("Latifabad Student Residence", "Hyderabad", "Latifabad", "hostel", 15500, "month", 1, 1, 1, "any", 0, 1, 1, 1, 0, 0, 1, 1, 4, 4.0, 4.2, 33, 25.3806, 68.3684, "Student-oriented shared accommodation with Wi-Fi, laundry and quick access to Latifabad transport routes.", "hyderabad-hostel"),
        ("Jinnahabad Hill Residence", "Abbottabad", "Jinnahabad", "house", 54000, "month", 2, 2, 1, "any", 1, 1, 1, 1, 1, 0, 1, 1, 3, 4.6, 4.5, 24, 34.1629, 73.2215, "Furnished two-bedroom residence suited to families, students and professionals in a quieter Abbottabad area.", "abbottabad-house"),
        ("Cantt Business Stay", "Sialkot", "Sialkot Cantt", "hotel", 8200, "night", 1, 1, 1, "any", 1, 0, 1, 1, 1, 1, 0, 1, 4, 4.4, 4.4, 47, 32.4945, 74.5229, "Short-stay rooms for business visitors with Wi-Fi, AC and convenient access to the cantonment area.", "sialkot-hotel"),
        ("DC Colony Family Portion", "Gujranwala", "DC Colony", "house", 68000, "month", 3, 2, 0, "any", 1, 0, 1, 1, 1, 1, 1, 0, 3, 4.5, 4.4, 19, 32.1877, 74.1945, "Family portion in a planned neighborhood with parking, security and access to schools and markets.", "gujranwala-house"),
    ]
    conn.executemany(
        """
        INSERT INTO listings(
            title,city,area,property_type,price,price_unit,bedrooms,bathrooms,furnished,
            gender_policy,family_friendly,student_friendly,security,wifi,parking,ac,kitchen,laundry,
            transport_score,safety_score,rating,reviews,lat,lng,description,image_key
        ) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
        """,
        rows,
    )


def seed_sale_listings(conn):
    rows = [
        ("F-11 Family House for Sale", "Islamabad", "F-11", "house", 87500000, 5, 6, 0, 12, "marla", "independent house", "agency", "Zameen", "https://www.zameen.com/", 33.6844, 72.9892, "Spacious demo family house with parking, servant room and easy access to F-11 Markaz.", "islamabad-house"),
        ("Bahria Town 10 Marla Home", "Rawalpindi", "Bahria Town Phase 8", "house", 36500000, 4, 5, 1, 10, "marla", "independent house", "owner", "Graana", "https://www.graana.com/", 33.4965, 73.1108, "Modern demo home in a gated community with family living spaces, parking and nearby commercial access.", "rawalpindi-house"),
        ("DHA Phase 6 One Kanal Residence", "Lahore", "DHA Phase 6", "house", 115000000, 5, 6, 0, 1, "kanal", "luxury house", "agency", "Zameen", "https://www.zameen.com/", 31.4679, 74.4565, "Premium demo one-kanal residence with multiple living areas, lawn and secure parking.", "lahore-house"),
        ("Bahria Orchard 10 Marla House", "Lahore", "Bahria Orchard", "house", 41000000, 4, 5, 1, 10, "marla", "independent house", "owner", "OLX Pakistan", "https://www.olx.com.pk/properties/", 31.3531, 74.1848, "Furnished demo house aimed at buyers seeking a planned community and motorway-side access.", "lahore-house"),
        ("DHA Karachi 500 Sq Yd House", "Karachi", "DHA Phase 6", "house", 155000000, 6, 7, 0, 500, "sq yd", "independent house", "agency", "Zameen", "https://www.zameen.com/", 24.7950, 67.0640, "Large demo residence for buyers looking for a central DHA location, multiple bedrooms and secure parking.", "karachi-house"),
        ("Gulshan 240 Sq Yd Family Home", "Karachi", "Gulshan-e-Iqbal", "house", 62500000, 4, 4, 0, 240, "sq yd", "family house", "owner", "OLX Pakistan", "https://www.olx.com.pk/properties/", 24.9270, 67.0950, "Practical demo family home close to schools, markets and major Gulshan road links.", "karachi-house"),
        ("Hayatabad 10 Marla Residence", "Peshawar", "Hayatabad Phase 3", "house", 42000000, 5, 5, 0, 10, "marla", "independent house", "agency", "Graana", "https://www.graana.com/", 33.9778, 71.4475, "Demo sale property for families preferring Hayatabad services, security and planned streets.", "peshawar-hotel"),
        ("Wapda City 10 Marla House", "Faisalabad", "Wapda City", "house", 26500000, 4, 4, 0, 10, "marla", "independent house", "owner", "Zameen", "https://www.zameen.com/", 31.4702, 73.1601, "Demo buy option in a planned Faisalabad neighborhood with parking and family-friendly surroundings.", "faisalabad-house"),
        ("DHA Multan 10 Marla Home", "Multan", "DHA Multan", "house", 25500000, 4, 4, 0, 10, "marla", "independent house", "agency", "Graana", "https://www.graana.com/", 30.1476, 71.3464, "Newer-style demo home with modern layout, parking and access to developing DHA commercial areas.", "multan-house"),
        ("Citi Housing 10 Marla House", "Sialkot", "Citi Housing", "house", 31000000, 4, 5, 1, 10, "marla", "independent house", "owner", "OLX Pakistan", "https://www.olx.com.pk/properties/", 32.5390, 74.5470, "Furnished demo sale listing in a gated society with family amenities and road connectivity.", "sialkot-hotel"),
    ]
    conn.executemany(
        """
        INSERT INTO listings(
            title,city,area,property_type,price,price_unit,bedrooms,bathrooms,furnished,
            gender_policy,family_friendly,student_friendly,security,wifi,parking,ac,kitchen,laundry,
            transport_score,safety_score,rating,reviews,lat,lng,description,image_key,listing_for,sale_price,
            area_size,area_unit,property_subtype,seller_type,source_name,source_url,listed_at
        ) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
        """,
        [
            (title, city, area, ptype, 0, "month", beds, baths, furnished, "any", 1, 0, 1, 1, 1, 1, 1, 1, 4, 4.5, 4.5, 0, lat, lng, desc, image, "sale", sale_price, area_size, area_unit, subtype, seller, source, url, "Demo inventory")
            for (title, city, area, ptype, sale_price, beds, baths, furnished, area_size, area_unit, subtype, seller, source, url, lat, lng, desc, image) in rows
        ],
    )


def seed_market_websites(conn):
    conn.executemany(
        "INSERT INTO market_websites(name,url,category,description) VALUES(?,?,?,?)",
        [
            ("Zameen", "https://www.zameen.com/", "Property marketplace", "External Pakistani property marketplace for browsing homes, plots and rental inventory."),
            ("Graana", "https://www.graana.com/", "Property marketplace", "External property platform for exploring residential and commercial opportunities."),
            ("OLX Pakistan", "https://www.olx.com.pk/properties/", "Classified marketplace", "External classifieds marketplace where users can independently search property advertisements."),
            ("Booking.com", "https://www.booking.com/", "Hotel marketplace", "External travel marketplace for independently checking hotel stays and availability."),
            ("Agoda", "https://www.agoda.com/", "Hotel marketplace", "External travel platform for independently comparing hotel accommodation."),
        ],
    )


def row_to_dict(row):
    data = dict(row)
    for key in ["furnished", "family_friendly", "student_friendly", "security", "wifi", "parking", "ac", "kitchen", "laundry", "verified_demo"]:
        if key in data:
            data[key] = bool(data[key])
    data["listing_for"] = data.get("listing_for") or "rent"
    if data["listing_for"] == "sale":
        data["display_price"] = data.get("sale_price") or 0
        data["monthly_estimate"] = None
    else:
        data["display_price"] = data.get("price") or 0
        data["monthly_estimate"] = data["price"] if data.get("price_unit") == "month" else data["price"] * 30
    return data


def make_token(user):
    payload = {
        "sub": str(user["id"]),
        "email": user["email"],
        "exp": datetime.now(timezone.utc) + timedelta(hours=JWT_EXP_HOURS),
    }
    return jwt.encode(payload, JWT_SECRET, algorithm="HS256")


def optional_user():
    auth = request.headers.get("Authorization", "")
    if not auth.startswith("Bearer "):
        return None
    try:
        payload = jwt.decode(auth.split(" ", 1)[1], JWT_SECRET, algorithms=["HS256"])
        return int(payload["sub"])
    except Exception:
        return None


def auth_required(fn):
    @wraps(fn)
    def wrapped(*args, **kwargs):
        user_id = optional_user()
        if not user_id:
            return jsonify({"error": "Authentication required"}), 401
        request.user_id = user_id
        return fn(*args, **kwargs)

    return wrapped


def normalized_monthly(listing):
    if listing.get("listing_for") == "sale":
        return 0
    return listing["price"] if listing["price_unit"] == "month" else listing["price"] * 30


def score_listing(listing, pref):
    score = 0
    reasons = []
    warnings = []

    intent = pref.get("intent", "rent")
    wanted_for = "sale" if intent == "buy" else "rent"
    if listing.get("listing_for", "rent") == wanted_for:
        score += 35
        reasons.append("Matches your buy requirement" if intent == "buy" else "Matches your rental requirement")
    else:
        return -100, 35, [], ["Different transaction type"]

    requested_type = pref.get("property_type", "any")
    if requested_type in ["house", "hostel", "hotel"]:
        if listing["property_type"] == requested_type:
            score += 24
            reasons.append(f"Matches your requested {requested_type} type")
        else:
            score -= 18

    city = (pref.get("city") or "").strip().lower()
    area = (pref.get("area") or "").strip().lower()
    if city:
        if listing["city"].lower() == city:
            score += 18
            reasons.append(f"Located in {listing['city']}")
        else:
            score -= 24
    if area:
        if area in listing["area"].lower() or listing["area"].lower() in area:
            score += 18
            reasons.append(f"Strong area match: {listing['area']}")
        else:
            score -= 3

    budget = int(pref.get("budget") or 0)
    if intent == "buy":
        listing_cost = int(listing.get("sale_price") or 0)
    else:
        budget_unit = pref.get("budget_unit", "month")
        listing_cost = listing["price"] if listing["price_unit"] == budget_unit else (
            normalized_monthly(listing) if budget_unit == "month" else max(1, round(normalized_monthly(listing) / 30))
        )
    if budget > 0 and listing_cost > 0:
        ratio = listing_cost / budget
        if ratio <= 1:
            score += 28
            reasons.append("Within your total buying budget" if intent == "buy" else "Within your target budget")
        elif ratio <= 1.15:
            score += 11
            warnings.append("Slightly above your target budget")
        else:
            score -= min(30, int((ratio - 1) * 35))
            warnings.append("Above your target budget")

    purpose = pref.get("purpose", "general")
    days = int(pref.get("stay_days") or 30)
    if intent == "rent":
        if days <= 14 and listing["property_type"] == "hotel":
            score += 15
            reasons.append("Well suited to a short stay")
        elif 14 < days <= 180 and listing["property_type"] == "hostel":
            score += 10
            reasons.append("Good fit for a medium-term stay")
        elif days > 30 and listing["property_type"] == "house":
            score += 12
            reasons.append("Better value for a longer stay")

    if purpose == "student":
        if listing["student_friendly"]:
            score += 14
            reasons.append("Student-friendly setup")
        if listing["wifi"]:
            score += 5
    elif purpose == "family":
        if listing["family_friendly"]:
            score += 15
            reasons.append("Family-friendly property")
        else:
            score -= 18
    elif purpose == "work":
        if listing["wifi"]:
            score += 8
            reasons.append("Internet-friendly")
        score += listing["transport_score"]

    gender = pref.get("gender", "any")
    if intent == "rent" and listing["property_type"] == "hostel" and listing["gender_policy"] != "any" and gender != "any":
        if listing["gender_policy"] == gender:
            score += 8
            reasons.append("Matches hostel gender preference")
        else:
            score -= 40
            warnings.append("Hostel gender policy does not match")

    required = set(pref.get("amenities") or [])
    amenity_map = {"wifi": "wifi", "parking": "parking", "ac": "ac", "kitchen": "kitchen", "laundry": "laundry", "security": "security", "furnished": "furnished"}
    for amenity in required:
        field = amenity_map.get(amenity)
        if field and listing[field]:
            score += 6
            reasons.append(f"Includes {amenity}")
        elif field:
            score -= 8
            warnings.append(f"Does not include {amenity}")

    score += round(listing["rating"] * 2)
    score += round(listing["safety_score"])
    score += listing["transport_score"]
    confidence = max(35, min(98, round(52 + score * 0.30)))
    return score, confidence, reasons[:5], warnings[:3]


def nominatim_search(query):
    global _last_nominatim_call
    if not NOMINATIM_ENABLED:
        return []

    conn = get_db()
    cache = conn.execute("SELECT payload FROM geo_cache WHERE query = ?", (query.lower(),)).fetchone()
    if cache:
        conn.close()
        return json.loads(cache["payload"])

    wait = 1.02 - (time.time() - _last_nominatim_call)
    if wait > 0:
        time.sleep(wait)

    params = urllib.parse.urlencode({"q": query, "format": "jsonv2", "countrycodes": "pk", "limit": 5, "addressdetails": 1})
    url = f"https://nominatim.openstreetmap.org/search?{params}"
    req = urllib.request.Request(url, headers={"User-Agent": f"NestWisePakistan/1.0 ({APP_CONTACT})"})
    try:
        with urllib.request.urlopen(req, timeout=8) as response:
            data = json.loads(response.read().decode("utf-8"))
        _last_nominatim_call = time.time()
        conn.execute(
            "INSERT OR REPLACE INTO geo_cache(query,payload,updated_at) VALUES(?,?,CURRENT_TIMESTAMP)",
            (query.lower(), json.dumps(data)),
        )
        conn.commit()
        return data
    except Exception:
        return []
    finally:
        conn.close()


def overpass_nearby(lat, lng, radius=1400):
    if not OVERPASS_ENABLED:
        return []
    query = f"""
    [out:json][timeout:12];
    (
      nwr(around:{radius},{lat},{lng})[amenity~"hospital|clinic|school|college|university|restaurant|cafe|bank|pharmacy"];
      nwr(around:{radius},{lat},{lng})[shop~"mall|supermarket"];
      nwr(around:{radius},{lat},{lng})[public_transport];
    );
    out center tags 45;
    """
    req = urllib.request.Request(
        "https://overpass-api.de/api/interpreter",
        data=urllib.parse.urlencode({"data": query}).encode("utf-8"),
        headers={"User-Agent": f"NestWisePakistan/1.0 ({APP_CONTACT})"},
        method="POST",
    )
    try:
        with urllib.request.urlopen(req, timeout=15) as response:
            payload = json.loads(response.read().decode("utf-8"))
        items = []
        for el in payload.get("elements", []):
            tags = el.get("tags", {})
            name = tags.get("name") or tags.get("brand") or "Nearby place"
            category = tags.get("amenity") or tags.get("shop") or tags.get("public_transport") or "place"
            coords = el.get("center", {})
            items.append({"name": name, "category": category, "lat": el.get("lat") or coords.get("lat"), "lng": el.get("lon") or coords.get("lon")})
        return items[:24]
    except Exception:
        return []


@app.get("/api/health")
def health():
    return jsonify({"status": "ok", "service": "NestWise Pakistan API", "database": "sqlite"})


@app.post("/api/auth/register")
def register():
    body = request.get_json(silent=True) or {}
    name = (body.get("name") or "").strip()
    email = (body.get("email") or "").strip().lower()
    password = body.get("password") or ""
    if len(name) < 2 or "@" not in email or len(password) < 8:
        return jsonify({"error": "Enter a valid name, email and password of at least 8 characters."}), 400
    conn = get_db()
    try:
        cur = conn.execute("INSERT INTO users(name,email,password_hash) VALUES(?,?,?)", (name, email, generate_password_hash(password)))
        conn.commit()
        user = conn.execute("SELECT id,name,email FROM users WHERE id=?", (cur.lastrowid,)).fetchone()
        return jsonify({"token": make_token(user), "user": dict(user)}), 201
    except sqlite3.IntegrityError:
        return jsonify({"error": "An account with this email already exists."}), 409
    finally:
        conn.close()


@app.post("/api/auth/login")
def login():
    body = request.get_json(silent=True) or {}
    conn = get_db()
    user = conn.execute("SELECT * FROM users WHERE email=?", ((body.get("email") or "").strip().lower(),)).fetchone()
    conn.close()
    if not user or not check_password_hash(user["password_hash"], body.get("password") or ""):
        return jsonify({"error": "Invalid email or password."}), 401
    public = {"id": user["id"], "name": user["name"], "email": user["email"]}
    return jsonify({"token": make_token(public), "user": public})


@app.get("/api/auth/me")
@auth_required
def me():
    conn = get_db()
    user = conn.execute("SELECT id,name,email,created_at FROM users WHERE id=?", (request.user_id,)).fetchone()
    conn.close()
    return jsonify(dict(user))


@app.get("/api/cities")
def cities():
    conn = get_db()
    rows = conn.execute("SELECT city, COUNT(*) count FROM listings GROUP BY city ORDER BY city").fetchall()
    conn.close()
    return jsonify([dict(r) for r in rows])


@app.get("/api/listings")
def listings():
    clauses = []
    params = []
    for key in ["city", "area", "property_type", "listing_for"]:
        value = request.args.get(key)
        if value:
            clauses.append(f"LOWER({key}) LIKE ?")
            params.append(f"%{value.lower()}%")
    min_price = request.args.get("min_price", type=int)
    max_price = request.args.get("max_price", type=int)
    effective_price = "CASE WHEN listing_for='sale' THEN COALESCE(sale_price,0) ELSE price END"
    if min_price is not None:
        clauses.append(f"{effective_price} >= ?")
        params.append(min_price)
    if max_price is not None:
        clauses.append(f"{effective_price} <= ?")
        params.append(max_price)
    where = " WHERE " + " AND ".join(clauses) if clauses else ""
    conn = get_db()
    rows = conn.execute(f"SELECT * FROM listings{where} ORDER BY listing_for, rating DESC, {effective_price} ASC", params).fetchall()
    conn.close()
    return jsonify([row_to_dict(r) for r in rows])


@app.get("/api/listings/<int:listing_id>")
def listing_detail(listing_id):
    conn = get_db()
    row = conn.execute("SELECT * FROM listings WHERE id=?", (listing_id,)).fetchone()
    conn.close()
    if not row:
        return jsonify({"error": "Listing not found"}), 404
    return jsonify(row_to_dict(row))


@app.post("/api/agent/recommend")
def agent_recommend():
    pref = request.get_json(silent=True) or {}
    conn = get_db()
    rows = [row_to_dict(r) for r in conn.execute("SELECT * FROM listings").fetchall()]
    conn.close()

    ranked = []
    for listing in rows:
        score, confidence, reasons, warnings = score_listing(listing, pref)
        if score > -20:
            ranked.append({**listing, "agent_score": score, "confidence": confidence, "reasons": reasons, "warnings": warnings})
    ranked.sort(key=lambda x: (x["agent_score"], x["rating"]), reverse=True)

    top = ranked[:5]
    budget = int(pref.get("budget") or 0)
    intent = pref.get("intent", "rent")
    unit = "total" if intent == "buy" else pref.get("budget_unit", "month")
    city = pref.get("city") or "your selected city"
    prop = pref.get("property_type", "any")
    if top:
        lead = top[0]
        action = "buying" if intent == "buy" else "renting"
        summary = f"I found {len(top)} strong options for {action} around {city}. {lead['title']} is the best current match at {lead['confidence']}% confidence because " + ", ".join(r.lower() for r in lead["reasons"][:3]) + "."
    else:
        summary = "I could not find a strong database match. Try increasing the budget, changing the area, or adjusting the property requirements."

    return jsonify({
        "summary": summary,
        "interpreted": {"city": city, "intent": intent, "property_type": prop, "budget": budget, "budget_unit": unit, "stay_days": int(pref.get("stay_days") or 30)},
        "recommendations": top,
        "note": "Property records and prices are portfolio demo data. External website links open independent marketplaces; live area context can use OpenStreetMap APIs."
    })


@app.get("/api/geo/search")
def geo_search():
    q = (request.args.get("q") or "").strip()
    if len(q) < 2:
        return jsonify([])
    data = nominatim_search(f"{q}, Pakistan")
    return jsonify([
        {"display_name": item.get("display_name"), "lat": float(item.get("lat")), "lng": float(item.get("lon")), "type": item.get("type")}
        for item in data if item.get("lat") and item.get("lon")
    ])


@app.get("/api/geo/nearby")
def nearby():
    lat = request.args.get("lat", type=float)
    lng = request.args.get("lng", type=float)
    if lat is None or lng is None:
        return jsonify({"error": "lat and lng are required"}), 400
    items = overpass_nearby(lat, lng)
    counts = {}
    for item in items:
        counts[item["category"]] = counts.get(item["category"], 0) + 1
    return jsonify({"items": items, "counts": counts, "source": "OpenStreetMap/Overpass API", "radius_m": 1400})


@app.get("/api/market-websites")
def market_websites():
    conn = get_db()
    rows = conn.execute("SELECT id,name,url,category,description FROM market_websites ORDER BY category,name").fetchall()
    conn.close()
    return jsonify([dict(r) for r in rows])


@app.get("/api/favorites")
@auth_required
def get_favorites():
    conn = get_db()
    rows = conn.execute(
        "SELECT l.* FROM listings l JOIN favorites f ON f.listing_id=l.id WHERE f.user_id=? ORDER BY f.created_at DESC",
        (request.user_id,),
    ).fetchall()
    conn.close()
    return jsonify([row_to_dict(r) for r in rows])


@app.post("/api/favorites/<int:listing_id>")
@auth_required
def toggle_favorite(listing_id):
    conn = get_db()
    exists = conn.execute("SELECT 1 FROM favorites WHERE user_id=? AND listing_id=?", (request.user_id, listing_id)).fetchone()
    if exists:
        conn.execute("DELETE FROM favorites WHERE user_id=? AND listing_id=?", (request.user_id, listing_id))
        active = False
    else:
        conn.execute("INSERT OR IGNORE INTO favorites(user_id,listing_id) VALUES(?,?)", (request.user_id, listing_id))
        active = True
    conn.commit()
    conn.close()
    return jsonify({"favorite": active})


@app.post("/api/inquiries")
def create_inquiry():
    body = request.get_json(silent=True) or {}
    required = [body.get("listing_id"), body.get("name"), body.get("phone")]
    if not all(required):
        return jsonify({"error": "listing_id, name and phone are required"}), 400
    user_id = optional_user()
    conn = get_db()
    listing = conn.execute("SELECT id FROM listings WHERE id=?", (body["listing_id"],)).fetchone()
    if not listing:
        conn.close()
        return jsonify({"error": "Listing not found"}), 404
    cur = conn.execute(
        "INSERT INTO inquiries(user_id,listing_id,name,phone,move_in,guests,message) VALUES(?,?,?,?,?,?,?)",
        (user_id, body["listing_id"], body["name"].strip(), body["phone"].strip(), body.get("move_in"), int(body.get("guests") or 1), (body.get("message") or "").strip()),
    )
    conn.commit()
    conn.close()
    return jsonify({"id": cur.lastrowid, "status": "pending", "message": "Inquiry saved. This demo does not send data to a real property owner."}), 201


@app.get("/api/inquiries")
@auth_required
def list_inquiries():
    conn = get_db()
    rows = conn.execute(
        """
        SELECT i.*, l.title, l.city, l.area
        FROM inquiries i JOIN listings l ON l.id=i.listing_id
        WHERE i.user_id=? ORDER BY i.created_at DESC
        """,
        (request.user_id,),
    ).fetchall()
    conn.close()
    return jsonify([dict(r) for r in rows])


if __name__ == "__main__":
    init_db()
    app.run(host="0.0.0.0", port=int(os.getenv("PORT", "5000")), debug=os.getenv("FLASK_DEBUG", "false").lower() == "true")
else:
    init_db()
