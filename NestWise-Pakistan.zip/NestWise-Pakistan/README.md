# NestWise Pakistan

**NestWise Pakistan** is a portfolio-ready full-stack React.js property and accommodation platform for people who want to **rent a house, find a hostel/hotel, or buy a house in Pakistan**. The built-in recommendation agent scores options against the user's budget, city/area, transaction type, stay duration, purpose, facilities, safety, transport, and purchase requirements.

> Important: The included rental prices and house sale prices are **sample/demo records** stored in the project database. They are not presented as live commercial listings. External property-marketplace links are provided for independent research, while live map-area context is fetched separately from OpenStreetMap services when available.

## Main Features

- Smart recommendation agent with explainable scoring
- Separate **Rent / Stay** and **Buy House** modes
- House, hostel, and hotel rental discovery
- House-for-sale discovery with total asking price
- Pakistan-focused coverage with **34 demo listings**, including **10 houses for sale**, across major cities
- Sale-price display in Pakistani lakh/crore format
- Property size support: marla, kanal, square yards
- Seller/agency type and external marketplace website fields
- Database-backed Property Websites page served through a REST API
- Monthly/nightly rental budget handling and total purchase-budget handling
- Stay duration logic
- Student, family, work, and general-use profiles
- Amenity requirements: Wi-Fi, parking, AC, kitchen, laundry, security, furnished
- Responsive search and filters
- User registration/login with hashed passwords and JWT
- Favorites saved in the database
- Booking/contact inquiry workflow saved in the database
- Live nearby-area information through OpenStreetMap/Overpass API
- Optional Pakistan geocoding endpoint through Nominatim
- Demo credentials
- Docker setup
- GitHub Actions CI/CD pipeline with backend tests, React production build, Docker validation, and continuous delivery artifacts
- Responsive desktop/tablet/mobile UI

## Tech Stack

### Frontend
- **React.js**
- Vite
- JavaScript
- CSS
- Lucide React icons

### Backend
- Python
- Flask REST API
- Flask-CORS
- JWT authentication
- Werkzeug password hashing

### Database
- SQLite (zero-configuration local database)

SQLite keeps the project easy to run locally. A production version can move the same data model to PostgreSQL/MySQL.

## Recommendation Agent

The agent is intentionally explainable. It first separates **buy** from **rent/stay** inventory, then ranks properties using factors such as transaction type, property type, city/area, total or recurring budget, length of stay when relevant, family/student/work purpose, required amenities, ratings, safety, and transport.

The response includes a confidence score, positive reasons, and warnings/trade-offs.

## House Sale & Property Website Features

Sale records add these database fields:

```text
listing_for = sale
sale_price
area_size
area_unit
property_subtype
seller_type
source_name
source_url
```

React renders sale prices as lakh/crore values and exposes independent marketplace links. The included external website directory is stored in the `market_websites` database table and returned by:

```text
GET /api/market-websites
```

The project currently includes links to Zameen, Graana, OLX Pakistan, Booking.com, and Agoda. These links are for independent research only; the demo properties are not claimed to be listings from those platforms.

## External APIs

### OpenStreetMap Overpass API
Used by:

`GET /api/geo/nearby?lat=...&lng=...`

It can return nearby hospitals/clinics, schools/universities, restaurants/cafes, pharmacies, shopping, banks, and public transport information around a recommended listing.

### Nominatim
Used by:

`GET /api/geo/search?q=F-8 Islamabad`

The backend sends an identifying User-Agent, caches results in SQLite, and limits uncached Nominatim requests to about one request per second. Set `APP_CONTACT_EMAIL` to a real project contact when deploying.

OpenStreetMap attribution must remain visible in any production implementation that displays OSM-derived data/maps. Public community endpoints are suitable for light demo usage, not heavy production traffic. For production scale, use a hosted provider or self-hosted service according to the relevant service terms.

## Demo Credentials

```text
Email: demo@nestwise.pk
Password: Demo123!
```

## How to Run — Easy Local Method

### 1. Start the backend

Open Terminal / PowerShell:

```bash
cd NestWise-Pakistan/backend
python -m venv .venv
```

Windows PowerShell:

```powershell
.\.venv\Scripts\Activate.ps1
pip install -r requirements.txt
python app.py
```

Backend:

```text
http://localhost:5000
```

The SQLite database and demo data are created automatically on first start.

### 2. Start the frontend

Open a second terminal:

```bash
cd NestWise-Pakistan/frontend
npm install
npm run dev
```

Frontend:

```text
http://localhost:5173
```

## Run with Docker

From the project root:

```bash
docker compose up --build
```

Then open:

```text
http://localhost:8080
```

Backend API runs at:

```text
http://localhost:5000/api
```

## CI/CD Pipeline

The repository includes a real GitHub Actions workflow at:

```text
.github/workflows/pipeline.yml
```

The pipeline automatically runs backend CI, React frontend CI, Flask API smoke tests, a production Vite build, Docker Compose validation, and Docker image builds. Successful pushes to `main` create a deployable release artifact. An optional `DEPLOY_HOOK_URL` GitHub secret can trigger deployment after delivery succeeds.

See `CI-CD-PIPELINE.md` for the full pipeline flow and GitHub setup instructions.

## Environment Variables

Backend example: `backend/.env.example`

```text
JWT_SECRET=replace-with-a-long-random-secret
APP_CONTACT_EMAIL=you@example.com
NOMINATIM_ENABLED=true
OVERPASS_ENABLED=true
PORT=5000
```

Frontend example: `frontend/.env.example`

```text
VITE_API_URL=http://localhost:5000/api
```

Never commit production secrets.

## Important API Routes

```text
GET    /api/health
POST   /api/auth/register
POST   /api/auth/login
GET    /api/auth/me
GET    /api/cities
GET    /api/listings
GET    /api/listings/:id
GET    /api/market-websites
POST   /api/agent/recommend
GET    /api/geo/search?q=...
GET    /api/geo/nearby?lat=...&lng=...
GET    /api/favorites
POST   /api/favorites/:listingId
POST   /api/inquiries
GET    /api/inquiries
```

## Example Agent Request

```json
{
  "intent": "buy",
  "city": "Islamabad",
  "area": "F-11",
  "property_type": "house",
  "budget": 90000000,
  "budget_unit": "total",
  "stay_days": 365,
  "purpose": "family",
  "gender": "any",
  "amenities": ["wifi", "parking", "security", "furnished"]
}
```

## Project Structure

```text
NestWise-Pakistan/
├── backend/
│   ├── app.py
│   ├── requirements.txt
│   ├── .env.example
│   └── Dockerfile
├── frontend/
│   ├── public/assets/
│   ├── src/
│   │   ├── App.jsx
│   │   ├── api.js
│   │   ├── main.jsx
│   │   └── styles.css
│   ├── package.json
│   ├── vite.config.js
│   ├── .env.example
│   └── Dockerfile
├── docker-compose.yml
├── .gitignore
└── README.md
```

## Production Upgrade Ideas

- PostgreSQL + SQLAlchemy
- Admin/landlord dashboard for verified listing management
- Real commercial property/hotel provider integration using an approved API and API key
- Moderation and identity verification
- Real-time availability calendar
- Verified owner/host profiles
- Secure payment provider suited to the deployment country
- Maps with a production-grade tile/geocoding provider
- Email/SMS notifications
- Image uploads to object storage
- AI natural-language layer on top of the deterministic ranking engine

## Portfolio / CV Description

**NestWise Pakistan — React.js Full-Stack Property Recommendation Platform**  
Built a React.js + Flask + SQLite platform for renting houses, finding hostels/hotels, and comparing houses for sale across Pakistan. Developed an explainable recommendation agent for rental and purchase budgets, lakh/crore sale pricing, property-size filters, REST APIs, JWT authentication, database-backed favorites/inquiries, external property-website integration, and OpenStreetMap-based nearby-area intelligence.

## Skills Demonstrated

React.js, JavaScript, CSS, Vite, Python, Flask, REST APIs, SQLite, JWT, Authentication, Database Design, Recommendation Systems, Property Marketplace UX, API Integration, Responsive Web Design, Docker, Git/GitHub, Form Validation, Search & Filtering, Full-Stack Development.
