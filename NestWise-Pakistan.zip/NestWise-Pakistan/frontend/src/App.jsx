import { useEffect, useMemo, useState } from 'react';
import {
  BadgeDollarSign, BedDouble, Building2, CheckCircle2, ChevronRight, CircleDollarSign,
  Compass, ExternalLink, Globe2, Heart, Home, Hotel, House, Landmark, LogIn, LogOut,
  MapPin, Menu, MessageCircle, Navigation, ParkingCircle, RefreshCcw, Ruler, Search,
  ShieldCheck, Sparkles, Star, Tags, Users, Wifi, X, Zap, GraduationCap, Clock3,
  Hospital, ShoppingBag, UtensilsCrossed
} from 'lucide-react';
import { api, clearSession, savedUser, setSession } from './api';

const number = new Intl.NumberFormat('en-PK');
const cityOptions = ['Islamabad', 'Rawalpindi', 'Lahore', 'Karachi', 'Peshawar', 'Faisalabad', 'Multan', 'Murree', 'Quetta', 'Hyderabad', 'Abbottabad', 'Sialkot', 'Gujranwala'];
const amenityOptions = [
  ['wifi', 'Wi-Fi'], ['parking', 'Parking'], ['ac', 'AC'], ['kitchen', 'Kitchen'],
  ['laundry', 'Laundry'], ['security', 'Security'], ['furnished', 'Furnished']
];
const imageMap = {
  'islamabad-house': '/assets/property-1.svg', 'islamabad-hotel': '/assets/property-2.svg', 'islamabad-hostel': '/assets/property-3.svg',
  'rawalpindi-hostel': '/assets/property-4.svg', 'rawalpindi-house': '/assets/property-5.svg', 'lahore-hotel': '/assets/property-6.svg',
  'lahore-hostel': '/assets/property-7.svg', 'lahore-house': '/assets/property-8.svg', 'karachi-hotel': '/assets/property-9.svg',
  'karachi-hostel': '/assets/property-10.svg', 'karachi-house': '/assets/property-11.svg', 'peshawar-hostel': '/assets/property-12.svg',
  'peshawar-hotel': '/assets/property-13.svg', 'faisalabad-house': '/assets/property-14.svg', 'faisalabad-hotel': '/assets/property-15.svg',
  'multan-hostel': '/assets/property-16.svg', 'multan-house': '/assets/property-17.svg', 'murree-hotel': '/assets/property-18.svg',
  'murree-house': '/assets/property-19.svg', 'quetta-house': '/assets/property-20.svg', 'hyderabad-hostel': '/assets/property-21.svg',
  'abbottabad-house': '/assets/property-22.svg', 'sialkot-hotel': '/assets/property-23.svg', 'gujranwala-house': '/assets/property-24.svg'
};

function formatPKR(value) {
  const amount = Number(value || 0);
  if (amount >= 10_000_000) return `PKR ${(amount / 10_000_000).toFixed(amount % 10_000_000 ? 2 : 0)} Crore`;
  if (amount >= 100_000) return `PKR ${(amount / 100_000).toFixed(amount % 100_000 ? 2 : 0)} Lakh`;
  return `PKR ${number.format(amount)}`;
}

function listingPrice(item) {
  if (item.listing_for === 'sale') return { main: formatPKR(item.sale_price), sub: 'total asking price' };
  return { main: `PKR ${number.format(item.price)}`, sub: `/${item.price_unit}` };
}

function Logo() {
  return <div className="brand"><div className="brand-mark"><Home size={21}/></div><div><strong>NestWise</strong><span>Pakistan</span></div></div>;
}

function App() {
  const [page, setPage] = useState('agent');
  const [mobileOpen, setMobileOpen] = useState(false);
  const [user, setUser] = useState(savedUser());
  const [authOpen, setAuthOpen] = useState(false);
  const [authMode, setAuthMode] = useState('login');
  const [listings, setListings] = useState([]);
  const [favorites, setFavorites] = useState([]);
  const [inquiries, setInquiries] = useState([]);
  const [loading, setLoading] = useState(true);

  async function loadListings() {
    setLoading(true);
    try { setListings(await api('/listings')); }
    finally { setLoading(false); }
  }

  async function loadUserData() {
    if (!user) { setFavorites([]); setInquiries([]); return; }
    try {
      const [fav, inq] = await Promise.all([api('/favorites'), api('/inquiries')]);
      setFavorites(fav); setInquiries(inq);
    } catch { /* expired token is handled by next login */ }
  }

  useEffect(() => { loadListings(); }, []);
  useEffect(() => { loadUserData(); }, [user]);

  const toggleFavorite = async (id) => {
    if (!user) return setAuthOpen(true);
    await api(`/favorites/${id}`, { method: 'POST' });
    await loadUserData();
  };

  const nav = [
    ['agent', Sparkles, 'AI Guide'], ['explore', Compass, 'Explore'], ['websites', Globe2, 'Websites'],
    ['favorites', Heart, 'Saved'], ['inquiries', MessageCircle, 'Inquiries']
  ];

  return <div className="app-shell">
    <header className="topbar">
      <Logo />
      <nav className="desktop-nav">
        {nav.map(([key, Icon, label]) => <button key={key} className={page === key ? 'active' : ''} onClick={() => setPage(key)}><Icon size={18}/>{label}</button>)}
      </nav>
      <div className="header-actions">
        {user ? <div className="user-chip"><div className="avatar">{user.name?.[0]?.toUpperCase()}</div><span>{user.name}</span><button className="icon-button" title="Log out" onClick={() => { clearSession(); setUser(null); setPage('agent'); }}><LogOut size={18}/></button></div>
          : <button className="primary small" onClick={() => setAuthOpen(true)}><LogIn size={18}/> Sign in</button>}
        <button className="icon-button mobile-menu" onClick={() => setMobileOpen(v => !v)}>{mobileOpen ? <X/> : <Menu/>}</button>
      </div>
    </header>

    {mobileOpen && <div className="mobile-panel">{nav.map(([key, Icon, label]) => <button key={key} className={page === key ? 'active' : ''} onClick={() => { setPage(key); setMobileOpen(false); }}><Icon size={19}/>{label}</button>)}</div>}

    <main>
      {page === 'agent' && <AgentPage onExplore={() => setPage('explore')} onFavorite={toggleFavorite} favoriteIds={new Set(favorites.map(x => x.id))} user={user} setAuthOpen={setAuthOpen}/>} 
      {page === 'explore' && <ExplorePage listings={listings} loading={loading} favoriteIds={new Set(favorites.map(x => x.id))} onFavorite={toggleFavorite} user={user} setAuthOpen={setAuthOpen}/>} 
      {page === 'websites' && <WebsitesPage/>}
      {page === 'favorites' && <CollectionPage items={favorites} onFavorite={toggleFavorite} user={user} setAuthOpen={setAuthOpen}/>} 
      {page === 'inquiries' && <InquiriesPage user={user} items={inquiries} setAuthOpen={setAuthOpen}/>} 
    </main>

    <footer><div><Logo/><p>React.js + Flask full-stack property guidance for renting and buying in Pakistan.</p></div><div className="footer-note"><ShieldCheck size={18}/> Demo property prices are separated from external marketplace websites.</div></footer>

    {authOpen && <AuthModal mode={authMode} setMode={setAuthMode} close={() => setAuthOpen(false)} onSuccess={(payload) => { setSession(payload); setUser(payload.user); setAuthOpen(false); }}/>} 
  </div>;
}

function AgentPage({ onExplore, onFavorite, favoriteIds, user, setAuthOpen }) {
  const [form, setForm] = useState({ intent: 'rent', city: 'Islamabad', area: '', property_type: 'any', budget: 60000, budget_unit: 'month', stay_days: 30, purpose: 'general', gender: 'any', amenities: ['wifi', 'security'] });
  const [result, setResult] = useState(null);
  const [busy, setBusy] = useState(false);
  const [areaInfo, setAreaInfo] = useState(null);
  const [geoBusy, setGeoBusy] = useState(false);

  const buying = form.intent === 'buy';
  const setIntent = (intent) => setForm(f => intent === 'buy'
    ? { ...f, intent, property_type: 'house', budget: 40000000, budget_unit: 'total', stay_days: 365, gender: 'any' }
    : { ...f, intent, property_type: 'any', budget: 60000, budget_unit: 'month', stay_days: 30 });
  const toggleAmenity = (key) => setForm(f => ({ ...f, amenities: f.amenities.includes(key) ? f.amenities.filter(x => x !== key) : [...f.amenities, key] }));

  async function runAgent(e) {
    e.preventDefault(); setBusy(true); setResult(null); setAreaInfo(null);
    try { setResult(await api('/agent/recommend', { method: 'POST', body: JSON.stringify(form) })); }
    catch (err) { setResult({ error: err.message, recommendations: [] }); }
    finally { setBusy(false); }
  }

  async function inspectArea(listing) {
    setGeoBusy(true); setAreaInfo({ title: listing.title, loading: true });
    try { setAreaInfo({ title: listing.title, ...(await api(`/geo/nearby?lat=${listing.lat}&lng=${listing.lng}`)) }); }
    catch { setAreaInfo({ title: listing.title, error: 'Live nearby-place service is unavailable right now.' }); }
    finally { setGeoBusy(false); }
  }

  return <>
    <section className="hero">
      <div className="hero-copy">
        <div className="eyebrow"><Sparkles size={16}/> Smart property agent</div>
        <h1>Rent a stay or <span>buy a home</span> with clearer choices.</h1>
        <p>Compare houses for sale, rental houses, hostels and hotels by budget, city, area, property size, stay needs, facilities and nearby services across Pakistan.</p>
        <div className="trust-row"><span><BadgeDollarSign/> Rent + buy pricing</span><span><MapPin/> Pakistan-focused</span><span><Globe2/> Property websites</span></div>
      </div>
      <div className="hero-visual">
        <div className="float-card a"><Hotel/><div><b>Short stay</b><small>Hotel matches</small></div></div>
        <div className="float-card b"><Tags/><div><b>Buy a house</b><small>Lakh & crore pricing</small></div></div>
        <div className="float-card c"><House/><div><b>Long term</b><small>Rental homes</small></div></div>
        <div className="city-orbit">PK</div>
      </div>
    </section>

    <section className="agent-layout section-wrap">
      <form className="agent-form card" onSubmit={runAgent}>
        <div className="section-title"><div><span className="step">01</span><h2>Build your requirement</h2></div><p>Navi scores the database against your needs.</p></div>

        <div className="intent-switch">
          <button type="button" className={!buying ? 'selected' : ''} onClick={() => setIntent('rent')}><Home size={19}/> Rent / Stay</button>
          <button type="button" className={buying ? 'selected' : ''} onClick={() => setIntent('buy')}><BadgeDollarSign size={19}/> Buy House</button>
        </div>

        <div className="form-grid two">
          <label>City<select value={form.city} onChange={e => setForm({ ...form, city: e.target.value })}>{cityOptions.map(c => <option key={c}>{c}</option>)}</select></label>
          <label>Preferred area<input value={form.area} onChange={e => setForm({ ...form, area: e.target.value })} placeholder="e.g. F-11, DHA, Gulberg, Clifton"/></label>
        </div>

        <div className={`property-switch ${buying ? 'buy-only' : ''}`}>
          {(buying ? [['house', House, 'House']] : [['any', Building2, 'Any'], ['house', House, 'House'], ['hostel', Users, 'Hostel'], ['hotel', Hotel, 'Hotel']]).map(([key, Icon, title]) =>
            <button type="button" key={key} className={form.property_type === key ? 'selected' : ''} onClick={() => setForm({ ...form, property_type: key })}><Icon size={21}/><span>{title}</span></button>)}
        </div>

        {buying ? <div className="form-grid two">
          <label>Total buying budget (PKR)<input type="number" min="1000000" step="500000" value={form.budget} onChange={e => setForm({ ...form, budget: Number(e.target.value) })}/><small className="input-help">{formatPKR(form.budget)}</small></label>
          <label>Buying purpose<select value={form.purpose} onChange={e => setForm({ ...form, purpose: e.target.value })}><option value="general">General purchase</option><option value="family">Family home</option><option value="work">Work / relocation</option></select></label>
        </div> : <>
          <div className="form-grid three">
            <label>Budget<input type="number" min="1000" value={form.budget} onChange={e => setForm({ ...form, budget: Number(e.target.value) })}/></label>
            <label>Budget period<select value={form.budget_unit} onChange={e => setForm({ ...form, budget_unit: e.target.value })}><option value="month">Per month</option><option value="night">Per night</option></select></label>
            <label>Stay length (days)<input type="number" min="1" max="730" value={form.stay_days} onChange={e => setForm({ ...form, stay_days: Number(e.target.value) })}/></label>
          </div>
          <div className="form-grid two">
            <label>Primary purpose<select value={form.purpose} onChange={e => setForm({ ...form, purpose: e.target.value })}><option value="general">General stay</option><option value="student">Study / student</option><option value="family">Family</option><option value="work">Work / relocation</option></select></label>
            <label>Hostel preference<select value={form.gender} onChange={e => setForm({ ...form, gender: e.target.value })}><option value="any">Any / not applicable</option><option value="men">Men</option><option value="women">Women</option></select></label>
          </div>
        </>}

        <div className="amenities"><span>Must-have facilities</span><div>{amenityOptions.map(([key, title]) => <button type="button" key={key} className={form.amenities.includes(key) ? 'active' : ''} onClick={() => toggleAmenity(key)}>{form.amenities.includes(key) && <CheckCircle2 size={15}/>} {title}</button>)}</div></div>
        <button className="primary agent-submit" disabled={busy}>{busy ? <><RefreshCcw className="spin"/> Scoring properties...</> : <><Sparkles/> Find my best matches</>}</button>
      </form>

      <aside className="agent-side card dark-card">
        <div className="agent-avatar"><Sparkles/></div><div className="status-dot"></div>
        <h3>Navi, your property guide</h3>
        <p>I can separate rental and purchase budgets, match locations and amenities, and explain why a house, hostel or hotel fits your requirement.</p>
        <div className="logic-list"><span><CircleDollarSign/> Price fit</span><span><Ruler/> Property size</span><span><Navigation/> Area & transport</span><span><ShieldCheck/> Safety</span><span><Wifi/> Facilities</span><span><Globe2/> Website links</span></div>
        <div className="demo-badge">Portfolio-safe full stack <small>Demo property inventory • external marketplaces • live OSM context</small></div>
      </aside>
    </section>

    {result && <section className="results section-wrap">
      <div className="result-intro"><div><div className="eyebrow"><Zap size={15}/> Agent analysis</div><h2>{result.error || 'Your strongest matches'}</h2><p>{result.summary}</p></div><button className="secondary" onClick={onExplore}>Browse all <ChevronRight size={17}/></button></div>
      <div className="recommend-grid">{result.recommendations?.map((item, index) => <PropertyCard key={item.id} item={item} rank={index + 1} isFavorite={favoriteIds.has(item.id)} onFavorite={() => onFavorite(item.id)} onArea={() => inspectArea(item)} user={user} setAuthOpen={setAuthOpen}/>)}</div>
      {areaInfo && <AreaPanel info={areaInfo} busy={geoBusy}/>} 
    </section>}
  </>;
}

function ExplorePage({ listings, loading, favoriteIds, onFavorite, user, setAuthOpen }) {
  const [filters, setFilters] = useState({ q: '', city: 'All', type: 'All', for: 'rent', max: 250000 });
  const isSale = filters.for === 'sale';

  function changeIntent(value) {
    setFilters(f => ({ ...f, for: value, type: value === 'sale' ? 'house' : 'All', max: value === 'sale' ? 200000000 : 250000 }));
  }

  const visible = useMemo(() => listings.filter(item => {
    const q = filters.q.toLowerCase();
    const effectivePrice = item.listing_for === 'sale' ? Number(item.sale_price || 0) : Number(item.price || 0);
    return item.listing_for === filters.for && (!q || `${item.title} ${item.city} ${item.area}`.toLowerCase().includes(q)) &&
      (filters.city === 'All' || item.city === filters.city) && (filters.type === 'All' || item.property_type === filters.type) && effectivePrice <= Number(filters.max);
  }), [listings, filters]);

  return <section className="section-wrap page-section">
    <div className="page-heading"><div><div className="eyebrow"><Compass size={15}/> Explore Pakistan</div><h1>{isSale ? 'Homes to buy' : 'Places to rent and stay'}</h1><p>{isSale ? 'Compare demo sale prices in lakh/crore, size, city, bedrooms and property website links.' : 'Filter rental houses, hostels and hotels by location, type and price.'}</p></div><div className="count-pill">{visible.length} places</div></div>

    <div className="explore-intent card"><button className={!isSale ? 'selected' : ''} onClick={() => changeIntent('rent')}><Home size={18}/> Rent / Stay</button><button className={isSale ? 'selected' : ''} onClick={() => changeIntent('sale')}><BadgeDollarSign size={18}/> Buy</button></div>

    <div className="filter-bar card">
      <div className="search-box"><Search size={19}/><input placeholder="Search area, city or property" value={filters.q} onChange={e => setFilters({ ...filters, q: e.target.value })}/></div>
      <select value={filters.city} onChange={e => setFilters({ ...filters, city: e.target.value })}><option>All</option>{cityOptions.map(c => <option key={c}>{c}</option>)}</select>
      <select value={filters.type} onChange={e => setFilters({ ...filters, type: e.target.value })}><option>All</option><option value="house">House</option>{!isSale && <><option value="hostel">Hostel</option><option value="hotel">Hotel</option></>}</select>
      <label className="price-filter"><span>Max {formatPKR(filters.max)}</span><input type="range" min={isSale ? 10000000 : 10000} max={isSale ? 200000000 : 250000} step={isSale ? 5000000 : 5000} value={filters.max} onChange={e => setFilters({ ...filters, max: Number(e.target.value) })}/></label>
    </div>
    {loading ? <div className="loading-state">Loading places…</div> : visible.length ? <div className="explore-grid">{visible.map(item => <PropertyCard key={item.id} item={item} isFavorite={favoriteIds.has(item.id)} onFavorite={() => onFavorite(item.id)} user={user} setAuthOpen={setAuthOpen}/>)}</div> : <EmptyState text="No properties match these filters. Increase the price or select another city."/>}
  </section>;
}

function WebsitesPage() {
  const [items, setItems] = useState([]);
  const [error, setError] = useState('');
  useEffect(() => { api('/market-websites').then(setItems).catch(err => setError(err.message)); }, []);

  return <section className="section-wrap page-section">
    <div className="page-heading"><div><div className="eyebrow"><Globe2 size={15}/> External property websites</div><h1>Continue your market research</h1><p>These website records are stored in the backend database and served to React through an API. They are independent external marketplaces; NestWise does not claim their inventory as its own.</p></div><div className="count-pill">{items.length} websites</div></div>
    {error ? <div className="notice error">{error}</div> : <div className="market-grid">{items.map(item => <article className="market-card card" key={item.id}><div className="market-icon"><Globe2/></div><span className="market-category">{item.category}</span><h3>{item.name}</h3><p>{item.description}</p><a href={item.url} target="_blank" rel="noreferrer">Open website <ExternalLink size={16}/></a></article>)}</div>}
    <div className="market-note card"><ShieldCheck size={21}/><div><b>Important</b><p>House prices shown inside NestWise are demo portfolio data. Use external property websites for independent live-market checking and due diligence.</p></div></div>
  </section>;
}

function CollectionPage({ items, onFavorite, user, setAuthOpen }) {
  return <section className="section-wrap page-section"><div className="page-heading"><div><div className="eyebrow"><Heart size={15}/> Personal shortlist</div><h1>Saved properties</h1><p>Your saved rental, stay and purchase options.</p></div></div>{!user ? <AuthRequired setAuthOpen={setAuthOpen}/> : items.length === 0 ? <EmptyState text="You have not saved any properties yet."/> : <div className="explore-grid">{items.map(item => <PropertyCard key={item.id} item={item} isFavorite onFavorite={() => onFavorite(item.id)} user={user} setAuthOpen={setAuthOpen}/>)}</div>}</section>;
}

function InquiriesPage({ user, items, setAuthOpen }) {
  return <section className="section-wrap page-section"><div className="page-heading"><div><div className="eyebrow"><MessageCircle size={15}/> Contact requests</div><h1>Your inquiries</h1><p>Track rental questions and demo buyer-interest requests saved in the backend.</p></div></div>{!user ? <AuthRequired setAuthOpen={setAuthOpen}/> : items.length === 0 ? <EmptyState text="No inquiries yet. Open a property and send a demo request."/> : <div className="inquiry-list">{items.map(item => <div className="inquiry card" key={item.id}><div><h3>{item.title}</h3><span><MapPin size={15}/>{item.area}, {item.city}</span></div><div><b>{item.status}</b><small>{new Date(item.created_at + 'Z').toLocaleDateString()}</small></div></div>)}</div>}</section>;
}

function PropertyCard({ item, rank, isFavorite, onFavorite, onArea, user, setAuthOpen }) {
  const [booking, setBooking] = useState(false);
  const TypeIcon = item.property_type === 'house' ? House : item.property_type === 'hostel' ? Users : Hotel;
  const price = listingPrice(item);
  const sale = item.listing_for === 'sale';

  return <article className="property-card card">
    <div className="property-image">
      <img src={imageMap[item.image_key] || '/assets/property-1.svg'} alt={`${item.title} illustration`}/>
      {rank && <div className="rank-badge">#{rank} match</div>}
      <button className={`heart-button ${isFavorite ? 'saved' : ''}`} onClick={onFavorite}><Heart size={19} fill={isFavorite ? 'currentColor' : 'none'}/></button>
      <div className="type-badge"><TypeIcon size={15}/>{item.property_type}</div>
      {sale && <div className="sale-badge">FOR SALE</div>}
    </div>
    <div className="property-body">
      <div className="property-heading"><div><h3>{item.title}</h3><span><MapPin size={14}/>{item.area}, {item.city}</span></div><div className="rating"><Star size={14} fill="currentColor"/>{item.rating}</div></div>
      <p>{item.description}</p>
      <div className="feature-row">
        {item.wifi && <span><Wifi/> Wi-Fi</span>}{item.security && <span><ShieldCheck/> Secure</span>}{item.parking && <span><ParkingCircle/> Parking</span>}
        {item.bedrooms > 0 && <span><BedDouble/> {item.bedrooms} beds</span>}{sale && item.area_size && <span><Ruler/> {item.area_size} {item.area_unit}</span>}
      </div>
      {sale && <div className="seller-row"><span><Tags size={14}/>{item.seller_type || 'seller'}</span>{item.property_subtype && <span>{item.property_subtype}</span>}</div>}
      {item.confidence && <div className="confidence"><div><span>Agent confidence</span><b>{item.confidence}%</b></div><div className="bar"><i style={{ width: `${item.confidence}%` }}></i></div>{item.reasons?.slice(0, 2).map(reason => <small key={reason}><CheckCircle2 size={13}/>{reason}</small>)}</div>}
      <div className="price-row"><div><strong>{price.main}</strong><span>{price.sub}</span></div><div className="card-actions">{onArea && <button className="icon-button bordered" title="Check nearby area" onClick={onArea}><Navigation size={18}/></button>}<button className="secondary compact" onClick={() => setBooking(true)}>{sale ? 'Contact seller' : 'Ask about it'}</button></div></div>
      {sale && item.source_url && <a className="source-link" href={item.source_url} target="_blank" rel="noreferrer"><Globe2 size={14}/> Search on {item.source_name || 'property website'} <ExternalLink size={13}/></a>}
      <small className="sample-note">Sample portfolio listing and price • not live commercial inventory</small>
    </div>
    {booking && <InquiryModal item={item} user={user} close={() => setBooking(false)} setAuthOpen={setAuthOpen}/>} 
  </article>;
}

function AreaPanel({ info, busy }) {
  const iconFor = (key) => key === 'hospital' || key === 'clinic' ? Hospital : key === 'restaurant' || key === 'cafe' ? UtensilsCrossed : key === 'mall' || key === 'supermarket' ? ShoppingBag : key === 'school' || key === 'college' || key === 'university' ? GraduationCap : Landmark;
  const entries = Object.entries(info.counts || {}).sort((a, b) => b[1] - a[1]).slice(0, 8);
  return <div className="area-panel card"><div className="area-head"><div><div className="eyebrow"><Navigation size={15}/> Live area context</div><h3>{info.title}</h3><p>Nearby public places from OpenStreetMap within about 1.4 km.</p></div><span className="live-pill">{busy ? 'Checking…' : 'OSM data'}</span></div>{info.error ? <div className="notice">{info.error}</div> : <div className="area-stats">{entries.length ? entries.map(([key, value]) => { const Icon = iconFor(key); return <div key={key}><Icon/><b>{value}</b><span>{key.replace('_', ' ')}</span></div>; }) : <span className="muted">No nearby categories returned by the live API.</span>}</div>}</div>;
}

function InquiryModal({ item, user, close }) {
  const sale = item.listing_for === 'sale';
  const [form, setForm] = useState({ name: user?.name || '', phone: '', move_in: '', guests: 1, message: sale ? `I am interested in buying ${item.title}. Please share more details.` : `I am interested in ${item.title}. Please share more details.` });
  const [status, setStatus] = useState('');
  async function submit(e) { e.preventDefault(); setStatus('Saving…'); try { const response = await api('/inquiries', { method: 'POST', body: JSON.stringify({ ...form, listing_id: item.id }) }); setStatus(response.message); } catch (err) { setStatus(err.message); } }
  return <div className="modal-backdrop" onMouseDown={e => e.target === e.currentTarget && close()}><div className="modal"><button className="modal-close" onClick={close}><X/></button><div className="eyebrow"><MessageCircle size={15}/> Demo inquiry</div><h2>{sale ? 'Buyer interest' : 'Ask about'} {item.title}</h2><p>This stores an inquiry in the project database; it does not contact a real seller or property owner.</p><form onSubmit={submit}><label>Your name<input required value={form.name} onChange={e => setForm({ ...form, name: e.target.value })}/></label><label>Phone<input required placeholder="03xx xxxxxxx" value={form.phone} onChange={e => setForm({ ...form, phone: e.target.value })}/></label>{!sale && <div className="form-grid two"><label>Move-in<input type="date" value={form.move_in} onChange={e => setForm({ ...form, move_in: e.target.value })}/></label><label>Guests<input type="number" min="1" max="10" value={form.guests} onChange={e => setForm({ ...form, guests: e.target.value })}/></label></div>}<label>Message<textarea rows="3" value={form.message} onChange={e => setForm({ ...form, message: e.target.value })}/></label>{status && <div className="notice success">{status}</div>}<button className="primary full">Save inquiry</button></form></div></div>;
}

function AuthModal({ mode, setMode, close, onSuccess }) {
  const [form, setForm] = useState({ name: '', email: 'demo@nestwise.pk', password: 'Demo123!' });
  const [error, setError] = useState(''); const [busy, setBusy] = useState(false);
  async function submit(e) { e.preventDefault(); setBusy(true); setError(''); try { onSuccess(await api(`/auth/${mode}`, { method: 'POST', body: JSON.stringify(form) })); } catch (err) { setError(err.message); } finally { setBusy(false); } }
  return <div className="modal-backdrop" onMouseDown={e => e.target === e.currentTarget && close()}><div className="modal auth-modal"><button className="modal-close" onClick={close}><X/></button><Logo/><h2>{mode === 'login' ? 'Welcome back' : 'Create your account'}</h2><p>{mode === 'login' ? 'Use the demo account or your own account.' : 'Save rental and purchase properties and track inquiries.'}</p><form onSubmit={submit}>{mode === 'register' && <label>Name<input required value={form.name} onChange={e => setForm({ ...form, name: e.target.value })}/></label>}<label>Email<input type="email" required value={form.email} onChange={e => setForm({ ...form, email: e.target.value })}/></label><label>Password<input type="password" required minLength="8" value={form.password} onChange={e => setForm({ ...form, password: e.target.value })}/></label>{error && <div className="notice error">{error}</div>}<button className="primary full" disabled={busy}>{busy ? 'Please wait…' : mode === 'login' ? 'Sign in' : 'Create account'}</button></form><div className="demo-login"><b>Demo credentials</b><span>demo@nestwise.pk</span><span>Demo123!</span></div><button className="text-button" onClick={() => setMode(mode === 'login' ? 'register' : 'login')}>{mode === 'login' ? 'Need an account? Register' : 'Already have an account? Sign in'}</button></div></div>;
}

function AuthRequired({ setAuthOpen }) { return <div className="auth-required card"><div><LogIn/></div><h2>Sign in to use this section</h2><p>Your saved properties and inquiries are stored in the backend database.</p><button className="primary" onClick={() => setAuthOpen(true)}>Sign in</button></div>; }
function EmptyState({ text }) { return <div className="empty-state card"><Search size={30}/><h3>Nothing here yet</h3><p>{text}</p></div>; }

export default App;
