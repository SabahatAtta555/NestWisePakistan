const API_BASE = import.meta.env.VITE_API_URL || 'http://localhost:5000/api';

export function getToken() {
  return localStorage.getItem('nestwise_token');
}

export function setSession(payload) {
  localStorage.setItem('nestwise_token', payload.token);
  localStorage.setItem('nestwise_user', JSON.stringify(payload.user));
}

export function clearSession() {
  localStorage.removeItem('nestwise_token');
  localStorage.removeItem('nestwise_user');
}

export function savedUser() {
  try { return JSON.parse(localStorage.getItem('nestwise_user') || 'null'); }
  catch { return null; }
}

export async function api(path, options = {}) {
  const headers = { 'Content-Type': 'application/json', ...(options.headers || {}) };
  const token = getToken();
  if (token) headers.Authorization = `Bearer ${token}`;
  const response = await fetch(`${API_BASE}${path}`, { ...options, headers });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(data.error || 'Request failed');
  return data;
}
