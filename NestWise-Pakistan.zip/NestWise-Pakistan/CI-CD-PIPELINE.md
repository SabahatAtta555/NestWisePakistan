# NestWise CI/CD Pipeline

NestWise Pakistan includes a GitHub Actions pipeline at:

```text
.github/workflows/pipeline.yml
```

## Pipeline Flow

```text
Push / Pull Request
        |
        +-------------------+
        |                   |
   Backend CI          Frontend CI
        |                   |
 Python 3.12            Node.js 22
 pip install            npm install
 compile check          React/Vite build
 API smoke tests        build artifact
        |                   |
        +---------+---------+
                  |
           Docker Validation
                  |
        docker compose config
        docker compose build
                  |
                  v
       Main branch push only
                  |
          Continuous Delivery
                  |
     tested frontend artifact
     + backend + Docker files
                  |
       deployable ZIP artifact
                  |
                  v
   Optional deployment webhook
```

## CI — Continuous Integration

The CI stage runs automatically for pushes and pull requests to `main` and `develop`.

### Backend CI

- Uses Python 3.12.
- Installs `backend/requirements.txt`.
- Compiles the Python source to catch syntax errors.
- Runs Flask API smoke tests.
- Disables external OpenStreetMap calls during tests so CI remains deterministic.

The smoke tests check:

- `/api/health`
- sale-property API results
- the house-buying recommendation agent

### React Frontend CI

- Uses Node.js 22.
- Installs React/Vite dependencies.
- Creates a production React build with `npm run build`.
- Publishes the tested `dist` directory as a GitHub Actions artifact.

### Docker Validation

This job starts only after backend and frontend CI pass. It validates `docker-compose.yml` and builds both full-stack Docker images.

## CD — Continuous Delivery

For a successful push to `main`, the pipeline creates a deployable ZIP containing:

- tested React production build
- Flask backend
- backend requirements
- backend Dockerfile
- Docker Compose configuration
- project README
- GitHub Actions workflow

The bundle is uploaded to GitHub Actions and retained for 30 days.

## Optional Automatic Deployment

The CD job supports an optional repository secret:

```text
DEPLOY_HOOK_URL
```

If this secret exists, GitHub Actions calls it after the delivery artifact is created. You can connect it to a deployment service that provides a secure deploy webhook. If the secret is not configured, the pipeline still completes continuous delivery and produces the deployable artifact.

Never put deployment tokens or webhook URLs directly in source code.

## Optional Frontend API URL

Create this GitHub repository variable when the deployed Flask API is hosted online:

```text
VITE_API_URL=https://your-api-domain.example/api
```

If it is not configured, CI builds against:

```text
http://localhost:5000/api
```

## GitHub Setup

1. Push the project to GitHub.
2. Open the repository **Actions** tab.
3. Open **NestWise CI/CD Pipeline**.
4. Push a change or run it manually with **Run workflow**.
5. Check that Backend CI, React Frontend CI, and Docker Validation pass.
6. On the `main` branch, download the generated delivery artifact from the completed workflow run.

For optional automatic deployment, add `DEPLOY_HOOK_URL` under repository **Settings → Secrets and variables → Actions → Secrets**.

For a hosted backend URL, add `VITE_API_URL` under **Settings → Secrets and variables → Actions → Variables**.

## DevOps / CV Skills Demonstrated

- CI/CD
- GitHub Actions
- Pipeline automation
- React.js production builds
- Python/Flask testing
- Docker
- Docker Compose
- Build validation
- Automated testing
- Artifact management
- Environment variables and repository secrets
- Continuous delivery
