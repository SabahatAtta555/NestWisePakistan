# How to Run NestWise Pakistan on Windows
> Frontend: **React.js + Vite** • Backend: **Flask REST API** • Database: **SQLite**


## Terminal 1 — Backend

Open the `NestWise-Pakistan` folder in VS Code. Open a new terminal and run:

```powershell
cd backend
py -m venv .venv
.\.venv\Scripts\Activate.ps1
pip install -r requirements.txt
python app.py
```

Keep this terminal open. The API should be available at:

```text
http://localhost:5000/api/health
```

If PowerShell blocks virtual-environment activation, run this once in that terminal:

```powershell
Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
```

Then activate again.

## Terminal 2 — Frontend

Open a second VS Code terminal:

```powershell
cd frontend
npm install
npm run dev
```

Open:

```text
http://localhost:5173
```

## Demo Login

```text
Email: demo@nestwise.pk
Password: Demo123!
```

## If live area data does not appear

The core recommendation system and database still work. The live area panel depends on public OpenStreetMap community services and your internet connection.


## v2 Features to Test

After the app opens:

1. Open **AI Guide** and switch between **Rent / Stay** and **Buy House**.
2. In Buy House mode, enter a total budget such as `90000000` and search Islamabad.
3. Open **Explore**, select **Buy**, and move the purchase-price slider.
4. Open **Websites** to confirm the React page loads marketplace records from the backend API.
5. Save a sale property and submit a buyer-interest inquiry using the demo login.

Sale prices and property records are demo portfolio data, not live market quotations.

## GitHub CI/CD Pipeline

After you upload the project to GitHub, GitHub Actions automatically runs the workflow in:

```text
.github/workflows/pipeline.yml
```

It validates the Flask backend, builds the React.js frontend, validates/builds Docker containers, and creates a delivery artifact after successful pushes to `main`.

See `CI-CD-PIPELINE.md` for the complete setup and optional deployment-hook instructions.
